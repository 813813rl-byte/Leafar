@echo off
setlocal EnableDelayedExpansion

echo ==============================
echo   RENOMEAR ZIPS PELA PASTA
echo ==============================
echo.

for /r %%F in (*.zip) do (
    set "ZIP=%%F"
    set "PASTA=%%~dpF"
    
    rem remove barra final
    set "PASTA=!PASTA:~0,-1!"
    
    rem pega só o nome da pasta
    for %%A in ("!PASTA!") do set "NOMEPASTA=%%~nxA"
    
    rem monta novo nome
    set "NOVO=%%~dpF!NOMEPASTA!.zip"
    
    if /I not "%%F"=="!NOVO!" (
        echo Renomeando:
        echo %%~nxF  ^>  !NOMEPASTA!.zip
        ren "%%F" "!NOMEPASTA!.zip"
    )
)

echo.
echo Concluido.
pause