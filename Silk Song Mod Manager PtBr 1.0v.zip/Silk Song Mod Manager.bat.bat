if exist config.bat call config.bat
@echo off
setlocal EnableDelayedExpansion
title SilkSong Lumafly
color 0C
mode con: cols=130 lines=35
cls
REM =========================
REM CONFIGURACOES
REM =========================
set SILKSONG_DIR=D:\Games\Hollow Knight - Silksong
set DESTINO=D:\Games\Hollow Knight - Silksong\BepInEx\plugins
set BASE=D:\Backup\Jogos\Silksong Mods\Mods
if exist config.bat call config.bat
:MENU
cls
echo ##############################################################################################################################
echo #                                                                                                                            #
echo #  ___  ____  __    _  _    ___  _____  _  _  ___    __  __  _____  ____     __  __    __    _  _    __    ___  ____  ____   #
echo # / __)(_  _)(  )  ( )/ )  / __)(  _  )( \( )/ __)  (  \/  )(  _  )(  _ \   (  \/  )  /__\  ( \( )  /__\  / __)( ___)(  _ \  #
echo # \__ \ _)(_  )(__  )  (   \__ \ )(_)(  )  (( (_-.   )    (  )(_)(  )(_) )   )    (  /(__)\  )  (  /(__)\( (_-. )__)  )   /  #
echo # (___/(____)(____)(_)\_)  (___/(_____)(_)\_)\___/  (_/\/\_)(_____)(____/   (_/\/\_)(__)(__)(_)\_)(__)(__)\___/(____)(_)\_)  #
echo #                                                                                                                            #
echo #                                                 S I L K S O N G   M O D                                                    #
echo #                                                    M A N A G E R                                                           #
echo #                                                                                                                            #
echo ##############################################################################################################################
echo.    
echo   [1] Jogar Silksong
echo   [2] Instalar Mods
echo   [3] Remover Mods
echo   [4] Configurar
echo   [0] Sair
echo.  
set /p OPCAO=--Escolha:

if "%OPCAO%"=="1" goto JOGAR
if "%OPCAO%"=="2" goto INSTALAR
if "%OPCAO%"=="3" goto REMOVER
if "%OPCAO%"=="4" goto CONFIGURACOES
if "%OPCAO%"=="0" exit

goto MENU

REM ==================================================
REM ================= INSTALAR =======================
REM ==================================================
:INSTALAR
cls
echo ==============================
echo Selecionar pasta de instalacao
echo ==============================
echo.

set COUNT=0
for /d %%D in ("%BASE%\*") do (
    set /a COUNT+=1
    set "PASTA[!COUNT!]=%%~fD"
    echo [!COUNT!] %%~nxD
)

if %COUNT%==0 (
    echo Nenhuma pasta encontrada.
    pause
    goto MENU
)

echo.
echo [0] Cancelar
set /p ESCOLHA=Digite o numero da pasta:

if "%ESCOLHA%"=="0" goto MENU
if not defined PASTA[%ESCOLHA%] (
    echo Opcao invalida.
    pause
    goto MENU
)

set "ORIGEM=!PASTA[%ESCOLHA%]!"

cls
echo Procurando ZIPs em:
echo %ORIGEM%
echo.

set ZIPCOUNT=0

for /r "%ORIGEM%" %%Z in (*.zip) do (
    set /a ZIPCOUNT+=1
    echo ------------------------------
    echo Instalando: %%~nxZ

    set "TEMPDIR=%TEMP%\Silksong_%%~nZ"
    if exist "!TEMPDIR!" rmdir /s /q "!TEMPDIR!"
    mkdir "!TEMPDIR!"

    powershell -command "Expand-Archive -Force '%%Z' '!TEMPDIR!'"

    set "MODPASTA=%DESTINO%\%%~nZ"
    mkdir "!MODPASTA!" >nul 2>&1

    xcopy "!TEMPDIR!\*" "!MODPASTA!\" /E /I /Y >nul

    rmdir /s /q "!TEMPDIR!"
    echo OK.
    echo.
    pause
    goto MENU
)

if %ZIPCOUNT%==0 (
    echo ❌ Nenhum ZIP encontrado nessa pasta.
) else (
    echo ==============================
    echo %ZIPCOUNT% mod(s) instalado(s).
)
pause
goto MENU

REM ==================================================
REM ================= REMOVER ========================
REM ==================================================
:REMOVER
cls
echo ==============================
echo        MODS ATIVOS
echo ==============================
echo.

set COUNT=0
for /d %%D in ("%DESTINO%\*") do (
    if /i not "%%~nxD"=="ConfigurationManager" (
        set /a COUNT+=1
        set "MOD[!COUNT!]=%%~fD"
        echo [!COUNT!] %%~nxD
    )
)

if %COUNT%==0 (
    echo Nenhum mod ativo encontrado.
    pause
    goto MENU
)

echo.
echo [0] Cancelar
set /p ESC=Digite o numero do mod que deseja remover:

if "%ESC%"=="0" goto MENU
if not defined MOD[%ESC%] (
    echo Opcao invalida.
    pause
    goto MENU
)

set "MODREMOVER=!MOD[%ESC%]!"

echo.
echo Removendo:
echo !MODREMOVER!
echo.

rmdir /s /q "!MODREMOVER!"

if exist "!MODREMOVER!" (
    echo Falha ao remover.
) else (
    echo Mod removido com sucesso.
)

pause
goto MENU
REM ==================================================
REM ================Configurar========================
REM ==================================================
:CONFIGURACOES
cls
echo [1]Localizacao das pastas
echo [0]Sair/Cancelar
set /p OPCAO=--Escolha:
if "%OPCAO%"=="1" goto LOCALIZAR_PASTAS
if "%OPCAO%"=="0" goto Menu
REM ==================================================
REM ========Configurar Localizacao das pastas=========
REM ==================================================
:LOCALIZAR_PASTAS
cls
echo Digite o caminho do Silksong.exe(tem que ter Hollow Knight Silksong.exe no final ou coisa parecida):
set /p SILKSONG_DIR=

if not exist "%SILKSONG_DIR%" (
    echo Caminho invalido.
    pause
    goto CONFIGURACOES
)

echo Pasta salva com sucesso!
pause
cls

echo Digite o caminho da pasta do BepInEx\Plugins:
set /p DESTINO=

if not exist "%DESTINO%" (
    echo Caminho invalido.
    pause
    goto CONFIGURACOES
)

echo Pasta salva com sucesso!
pause
cls
echo Digite o caminho da pasta dos Mods(pasta onde tem todas as pastas de Mods):
set /p BASE=

if not exist "%BASE%" (
    echo Caminho invalido.
    pause
    goto CONFIGURACOES
)

echo Pasta salva com sucesso!

pause
cls
echo Salvando configuracoes...

(
echo set SILKSONG_DIR=%SILKSONG_DIR%
echo set DESTINO=%DESTINO%
echo set BASE=%BASE%
) > config.bat

echo Configuracoes salvas com sucesso!
pause
cls
goto CONFIGURACOES
REM ==================================================
REM ================ JOGAR SILKSONG ==================
REM ==================================================
:JOGAR
cls
echo Abrindo Hollow Knight: Silksong...
echo.

start "" "D:\Games\Hollow Knight - Silksong\Hollow Knight Silksong.exe"

REM Fecha o .bat completamente
exit







:FIM
endlocal
exit /b