Silksong Mod Manager (Versão Pt-BR)

Essa é a versão em português que eu fiz.
Esse "Hollow Knight: Silksong Mod Manager" foi difícil de construir e ainda está em desenvolvimento.

IMPORTANTE:
NÃO delete o arquivo config.bat.
É nele que todas as suas configurações e caminhos ficam salvos.

Como usar:
1. Abra o Mod Manager
2. Vá em Configurações
3. Entre em Localização das Pastas
4. Configure os seguintes caminhos:
   - Caminho do arquivo .exe do Silksong
   - Caminho da pasta BepInEx\plugins
   - Caminho da pasta que contém todas as pastas de mods

OBS:
Os mods DEVEM estar dentro de pastas, e cada pasta deve conter o arquivo ZIP do mod.

Feito por Leafar 813813rl@gmail.com